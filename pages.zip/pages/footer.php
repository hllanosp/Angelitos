<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<div  id = "footer">
		<footer class="text-center"><strong> Sistema creado por el equipo de Seguridad Informatica</strong></footer>
		
	</div>
</body>
</html>